repo: CamBam09/Kehe_Prototype
branch: main
path: frontend/, backend/app/, backend/data/kehe_products.csv

## Last sync
date: 2026-09-04T00:33:32Z

### Updated in this project
- Rebuilt `frontend/index.html` dashboard as a standalone prototype (`KeHe Trend Dashboard.dc.html`) addressing the root-cause brief: replaced the Google Trends line chart with a product search + interactive US state-interest map + live social mentions feed.
- Removed the "Viral moment signals" section entirely.
- Replaced "Catalog & sales overview" with a seasonal demand forecast: product picker + Fall/Spring/Summer/Winter buttons driving an illustrative 12-week forecast chart.
- Rebuilt `frontend/catalog.html` as `KeHe Catalog.dc.html`: searchable product table, per-product detail panel with history+forecast chart and seasonality summary, mirroring the "no sales data" vs "demo data" distinction from the original.
- Product list and categories grounded in `backend/data/kehe_products.csv`; map/comments/forecast/history data are simulated placeholders (no live Google Trends/Bluesky/ML wiring, per prototype scope).

## Screen map
| Project screen | Repo source |
|---|---|
| KeHe Trend Dashboard.dc.html | frontend/index.html, backend/app/trends.py, backend/app/signals.py, backend/data/kehe_products.csv |
| KeHe Catalog.dc.html | frontend/catalog.html, backend/app/models.py, backend/seed_demo_data.py, backend/data/kehe_products.csv |
